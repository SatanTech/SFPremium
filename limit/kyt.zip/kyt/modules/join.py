from xolpanel import *
import json
import datetime

@bot.on(events.NewMessage(pattern=r"(?:.join|/join)$"))
@bot.on(events.CallbackQuery(data=b'join'))
async def join(event):
	

		# tmtunnel create $protocol $exp1 $username 2 1
		# record sender id
		cmd = f'tmb record {event.sender_id}'
		try:
			outputsc = subprocess.check_output(cmd, shell=True).decode("utf-8")
			
		except:
			await event.respond("**User Already Exist**")
		else:
			# data = json.loads(outputsc)
			# limitbw from b to gb
			

			msg = f"""
{outputsc}
"""
			await event.respond(msg)
			return
